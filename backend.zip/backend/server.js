const express = require('express');
const multer = require('multer');
const path = require('path');
const { imageUploadMiddleware } = require('./middleware/imageUploadMiddleware');
const cors = require('cors')
const app = express();
const port = 5000;
app.use(cors())

app.post("/upload", imageUploadMiddleware("image"), (req, res) => {

    res.status(200).send("image has been stored in folder")

})

app.get("/", (req, res) => {
    res.send("Server is running")
});
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
